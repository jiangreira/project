
-- --------------------------------------------------------

--
-- 資料表結構 `picker_prod`
--

CREATE TABLE `picker_prod` (
  `Id` int(10) UNSIGNED NOT NULL COMMENT '商品編號',
  `Name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品名稱',
  `ShortDesc` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '簡短敘述',
  `ProdDesc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品敘述',
  `CateId` int(3) NOT NULL COMMENT '分類編號',
  `MainPic` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '圖片',
  `CostPrice` int(10) DEFAULT NULL COMMENT '成本',
  `Price` int(10) NOT NULL COMMENT '售價',
  `Nprice` int(10) NOT NULL COMMENT '一般會員價',
  `PkPrice` int(10) NOT NULL COMMENT '會員價',
  `isMainSale` int(1) DEFAULT 0 COMMENT '是否為強檔商品(0:否1是)',
  `isDelete` int(1) DEFAULT 0 COMMENT '是否刪除(0:否1是)',
  `Credate` datetime NOT NULL COMMENT '新增時間',
  `Upddate` datetime NOT NULL COMMENT '修改時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Picker_商品';
