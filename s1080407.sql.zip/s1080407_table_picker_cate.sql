
-- --------------------------------------------------------

--
-- 資料表結構 `picker_cate`
--

CREATE TABLE `picker_cate` (
  `Id` int(3) UNSIGNED NOT NULL COMMENT '分類編號',
  `Floor` int(1) NOT NULL COMMENT '分類階層(0:父 1:子)',
  `Name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '分類名稱',
  `ParentId` int(3) NOT NULL COMMENT '父階層編號',
  `Sort` int(11) DEFAULT NULL COMMENT '順序',
  `isDelete` int(1) DEFAULT 0 COMMENT '是否刪除(0否1是)',
  `Credate` datetime NOT NULL COMMENT '新增時間',
  `Upddate` datetime NOT NULL COMMENT '修改時間'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 傾印資料表的資料 `picker_cate`
--

INSERT INTO `picker_cate` (`Id`, `Floor`, `Name`, `ParentId`, `Sort`, `isDelete`, `Credate`, `Upddate`) VALUES
(2, 0, '連線', 0, NULL, 0, '2020-01-05 19:23:18', '2020-01-05 19:23:18'),
(3, 0, '一月份穿搭', 0, NULL, 0, '2020-01-05 19:23:56', '2020-01-05 19:23:56'),
(10, 1, '不好穿', 3, NULL, 0, '2020-01-06 00:40:55', '2020-01-06 00:40:55');
