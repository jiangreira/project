
--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `picker_cate`
--
ALTER TABLE `picker_cate`
  ADD PRIMARY KEY (`Id`);

--
-- 資料表索引 `picker_prod`
--
ALTER TABLE `picker_prod`
  ADD PRIMARY KEY (`Id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `picker_cate`
--
ALTER TABLE `picker_cate`
  MODIFY `Id` int(3) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '分類編號', AUTO_INCREMENT=11;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `picker_prod`
--
ALTER TABLE `picker_prod`
  MODIFY `Id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '商品編號';
